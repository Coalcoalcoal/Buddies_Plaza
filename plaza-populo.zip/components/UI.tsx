
import React, { useEffect, useState } from 'react';
import { Buddy, WeatherCondition } from '../types';
import { getRelationshipColor, getRelationshipTier } from '../constants';
import { Clock, Save, RotateCcw, Activity, Zap, Smile, MessageCircle, Sun, Cloud, CloudRain, LogOut } from 'lucide-react';

interface UIProps {
  selectedBuddy: Buddy | null;
  allBuddies: Buddy[];
  onReset: () => void;
  onSave: () => void;
  onExit: () => void;
  lastSaved: Date | null;
  weather: WeatherCondition;
}

export const UI: React.FC<UIProps> = ({ selectedBuddy, allBuddies, onReset, onSave, onExit, lastSaved, weather }) => {
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const getBuddyName = (id: string) => allBuddies.find(b => b.id === id)?.name || "Unknown";

  const renderWeatherIcon = () => {
    switch(weather) {
      case WeatherCondition.RAINY: return <CloudRain className="w-6 h-6 text-blue-400" />;
      case WeatherCondition.CLOUDY: return <Cloud className="w-6 h-6 text-gray-400" />;
      case WeatherCondition.SUNNY: default: return <Sun className="w-6 h-6 text-yellow-400" />;
    }
  };

  return (
    <div className="absolute inset-0 pointer-events-none flex flex-col justify-between p-4 select-none">
      {/* Top Bar: Clock & Weather & Global Controls */}
      <div className="flex justify-between items-start pointer-events-none w-full">
        <div className="flex flex-col gap-2 pointer-events-auto">
            <div className="bg-white/90 backdrop-blur-sm p-3 rounded-2xl shadow-lg border-b-4 border-toon-blue flex items-center gap-3">
                <Clock className="w-6 h-6 text-toon-blue" />
                <span className="text-xl font-bold font-mono text-gray-700">
                    {time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
            </div>
             <div className="bg-white/90 backdrop-blur-sm p-2 px-3 rounded-2xl shadow-lg border-b-4 border-gray-300 flex items-center gap-3 self-start">
                {renderWeatherIcon()}
                <span className="font-bold text-gray-600">{weather}</span>
            </div>
        </div>

        <div className="flex gap-2 pointer-events-auto">
             <button 
                onClick={onSave}
                className="bg-white/90 p-3 rounded-xl shadow-lg border-b-4 border-toon-green hover:bg-green-50 active:border-b-0 active:translate-y-1 transition-all flex items-center gap-2 font-bold text-gray-700"
            >
                <Save className="w-5 h-5 text-toon-green" />
                {lastSaved ? 'Saved!' : 'Save'}
            </button>
            <button 
                onClick={onReset}
                className="bg-white/90 p-3 rounded-xl shadow-lg border-b-4 border-toon-red hover:bg-red-50 active:border-b-0 active:translate-y-1 transition-all"
                title="Reset Simulation"
            >
                <RotateCcw className="w-5 h-5 text-toon-red" />
            </button>
            <div className="w-px bg-black/10 mx-1"></div>
            <button 
                onClick={onExit}
                className="bg-gray-800/90 text-white p-3 rounded-xl shadow-lg border-b-4 border-black hover:bg-gray-700 active:border-b-0 active:translate-y-1 transition-all flex items-center gap-2 font-bold"
                title="Exit to Menu"
            >
                <LogOut className="w-5 h-5" />
                Exit
            </button>
        </div>
      </div>

      {/* Bottom Panel: Selected Buddy Stats */}
      <div className="flex justify-end items-end pointer-events-none w-full">
        {selectedBuddy ? (
          <div className="bg-white/95 backdrop-blur-md w-full max-w-sm rounded-3xl shadow-2xl border-4 border-gray-200 overflow-hidden animate-in slide-in-from-bottom-10 fade-in duration-300 pointer-events-auto select-none relative">
            {/* Header */}
            <div className="p-4 relative" style={{ backgroundColor: selectedBuddy.color }}>
                <h2 className="text-2xl font-black text-white drop-shadow-md pr-8">{selectedBuddy.name}</h2>
                <div className="flex gap-2 text-white/90 font-bold text-sm mt-1">
                    <span className="bg-black/20 px-2 py-0.5 rounded-lg">{selectedBuddy.gender}</span>
                    <span className="bg-black/20 px-2 py-0.5 rounded-lg">{selectedBuddy.currentActivity}</span>
                </div>
            </div>
            
            <div className="p-5 max-h-[60vh] overflow-y-auto">
                {/* Personality Traits */}
                <div className="grid grid-cols-2 gap-3 mb-6">
                    <div className="bg-gray-50 p-2 rounded-xl border border-gray-100">
                        <div className="flex items-center gap-2 text-gray-500 mb-1 text-xs font-bold uppercase tracking-wider">
                            <Zap className="w-3 h-3" /> Energy
                        </div>
                        <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                            <div className="h-full bg-yellow-400" style={{ width: `${selectedBuddy.personality.energy}%` }} />
                        </div>
                    </div>
                    <div className="bg-gray-50 p-2 rounded-xl border border-gray-100">
                         <div className="flex items-center gap-2 text-gray-500 mb-1 text-xs font-bold uppercase tracking-wider">
                            <Smile className="w-3 h-3" /> Mood
                        </div>
                        <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                            <div className="h-full bg-pink-400" style={{ width: `${selectedBuddy.personality.mood}%` }} />
                        </div>
                    </div>
                     <div className="bg-gray-50 p-2 rounded-xl border border-gray-100">
                         <div className="flex items-center gap-2 text-gray-500 mb-1 text-xs font-bold uppercase tracking-wider">
                            <Activity className="w-3 h-3" /> Overall
                        </div>
                        <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                            <div className="h-full bg-purple-400" style={{ width: `${selectedBuddy.personality.overall}%` }} />
                        </div>
                    </div>
                     <div className="bg-gray-50 p-2 rounded-xl border border-gray-100">
                         <div className="flex items-center gap-2 text-gray-500 mb-1 text-xs font-bold uppercase tracking-wider">
                            <MessageCircle className="w-3 h-3" /> Speech
                        </div>
                        <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                            <div className="h-full bg-blue-400" style={{ width: `${selectedBuddy.personality.speech}%` }} />
                        </div>
                    </div>
                </div>

                {/* Relationships */}
                <h3 className="font-bold text-gray-800 mb-3 flex items-center gap-2">
                    <span>❤️ Relationships</span>
                    <span className="text-xs font-normal text-gray-400 bg-gray-100 px-2 rounded-full">{Object.keys(selectedBuddy.relationships).length} met</span>
                </h3>
                <div className="space-y-2">
                    {Object.entries(selectedBuddy.relationships)
                     .sort(([, a], [, b]) => b.score - a.score)
                     .map(([id, rel]) => (
                        <div key={id} className="flex justify-between items-center p-2 hover:bg-gray-50 rounded-lg transition-colors border-b border-gray-50 last:border-0">
                            <span className="font-medium text-gray-700">{getBuddyName(id)}</span>
                            <div className="text-right">
                                <div className={`text-sm ${getRelationshipColor(rel.score)}`}>
                                    {getRelationshipTier(rel.score)}
                                </div>
                                <div className="w-20 h-1 bg-gray-100 rounded-full ml-auto mt-1">
                                    <div 
                                        className={`h-full rounded-full ${rel.score > 0 ? 'bg-green-400' : 'bg-red-400'}`} 
                                        style={{ width: `${Math.abs(rel.score)}%` }} 
                                    />
                                </div>
                            </div>
                        </div>
                    ))}
                    {Object.keys(selectedBuddy.relationships).length === 0 && (
                        <p className="text-gray-400 italic text-sm text-center py-4">Hasn't met anyone yet...</p>
                    )}
                </div>
            </div>
          </div>
        ) : (
             <div className="bg-white/80 backdrop-blur px-6 py-4 rounded-full shadow-xl mb-8 animate-pulse border-2 border-white pointer-events-auto select-none">
                <p className="text-gray-600 font-bold">👈 Click on a buddy to spy on them!</p>
             </div>
        )}
      </div>
    </div>
  );
};
