import React, { useRef, useMemo } from 'react';
import { useFrame, ThreeElements } from '@react-three/fiber';
import { Group, Vector3 as ThreeVector3, Mesh } from 'three';
import { Buddy, ActivityState } from '../types';
import { Text, Float } from '@react-three/drei';

// Extend JSX.IntrinsicElements to include Three.js elements
declare global {
  namespace JSX {
    interface IntrinsicElements extends ThreeElements {}
  }
}

interface BuddyMeshProps {
  buddy: Buddy;
  onClick: (id: string) => void;
  isSelected: boolean;
}

export const BuddyMesh: React.FC<BuddyMeshProps> = ({ buddy, onClick, isSelected }) => {
  const groupRef = useRef<Group>(null);
  const bodyRef = useRef<Mesh>(null);
  
  // Smooth movement and procedural animation
  useFrame((state, delta) => {
    if (!groupRef.current) return;

    // Position interpolation
    const currentPos = groupRef.current.position;
    const targetX = buddy.position.x;
    const targetZ = buddy.position.z;

    // Smooth lerp to logic position
    currentPos.x += (targetX - currentPos.x) * 0.1;
    currentPos.z += (targetZ - currentPos.z) * 0.1;
    
    // Rotation lerp
    groupRef.current.rotation.y = buddy.rotation;

    // Procedural Animation based on Activity
    const time = state.clock.getElapsedTime();
    
    if (bodyRef.current) {
      // Default reset
      let targetY = 0.75;
      bodyRef.current.rotation.set(0, 0, 0);

      switch (buddy.currentActivity) {
        case ActivityState.WALKING:
          // Bobbing
          targetY = 0.75 + Math.sin(time * 15) * 0.1;
          // Waddle
          bodyRef.current.rotation.z = Math.sin(time * 15) * 0.05;
          break;
        case ActivityState.DANCING:
          targetY = 0.75 + Math.abs(Math.sin(time * 10)) * 0.2; // Jump
          bodyRef.current.rotation.z = Math.sin(time * 8) * 0.2; // Sway
          groupRef.current.rotation.y += Math.sin(time * 5) * 0.05; // Spinny vibe
          break;
        case ActivityState.EXERCISING:
          // Jumping jacks simulation
          targetY = 0.75 + Math.abs(Math.sin(time * 8)) * 0.3;
          bodyRef.current.scale.x = 1 + Math.sin(time * 15) * 0.1;
          break;
        case ActivityState.PLAYING:
          // Happy hopping / Game
          targetY = 0.75 + Math.abs(Math.sin(time * 12)) * 0.15;
          bodyRef.current.rotation.z = Math.sin(time * 20) * 0.05; // Shaking with excitement
          break;
        case ActivityState.TALKING:
          // Slight nod
          bodyRef.current.rotation.x = Math.sin(time * 10) * 0.05;
          break;
        case ActivityState.EATING:
          // Bop up and down slightly
          targetY = 0.75 + Math.sin(time * 4) * 0.02;
          // Lean back slightly
          bodyRef.current.rotation.x = -0.1 + Math.sin(time * 8) * 0.05; 
          break;
        case ActivityState.READING:
        case ActivityState.SITTING:
          // Lower down
          targetY = 0.4;
          if (buddy.currentActivity === ActivityState.READING) {
             // Look down
             bodyRef.current.rotation.x = 0.4;
          }
          break;
        case ActivityState.SLEEPING:
          // Lying down
          targetY = 0.2;
          bodyRef.current.rotation.x = -Math.PI / 2; // Lay flat
          bodyRef.current.rotation.z = Math.PI / 4; // Slight tilt comfortably
          
          // Slow breathing while sleeping
          bodyRef.current.scale.x = 1 + Math.sin(time * 2) * 0.05;
          bodyRef.current.scale.z = 1 + Math.sin(time * 2) * 0.05; 
          break;
        case ActivityState.IDLE:
        default:
          // Breathing
          bodyRef.current.scale.y = 1 + Math.sin(time * 2) * 0.02;

          // Randomized Idle Animations (Weight shifting & Looking around)
          const seed = buddy.id.charCodeAt(0) || 0;
          bodyRef.current.rotation.z = Math.sin(time * 0.7 + seed) * 0.04;
          const lookOscillation = Math.sin(time * 0.4 + seed) + Math.sin(time * 0.9 + seed * 2) * 0.5;
          bodyRef.current.rotation.y = lookOscillation * 0.2; 
          break;
      }
      
      // Apply Y position smoothly
      bodyRef.current.position.y += (targetY - bodyRef.current.position.y) * 0.1;
    }
  });

  const emote = useMemo(() => {
    switch(buddy.currentActivity) {
      case ActivityState.TALKING: return "💬";
      case ActivityState.DANCING: return "🎵";
      case ActivityState.EXERCISING: return "💪";
      case ActivityState.PLAYING: return "🎮";
      case ActivityState.READING: return "📖";
      case ActivityState.EATING: return "🍎";
      case ActivityState.SLEEPING: return "Zzz";
      default: return "";
    }
  }, [buddy.currentActivity]);

  return (
    <group ref={groupRef} position={[buddy.position.x, 0, buddy.position.z]} onClick={(e) => { e.stopPropagation(); onClick(buddy.id); }}>
      {/* Selection Indicator */}
      {isSelected && (
        <mesh position={[0, 0.05, 0]} rotation={[-Math.PI / 2, 0, 0]}>
          <ringGeometry args={[0.8, 1, 32]} />
          <meshBasicMaterial color="white" opacity={0.5} transparent />
        </mesh>
      )}

      {/* Body */}
      <mesh ref={bodyRef} position={[0, 0.75, 0]} castShadow receiveShadow>
        <capsuleGeometry args={[0.4, 1, 4, 8]} />
        <meshStandardMaterial color={buddy.color} roughness={0.3} metalness={0.1} />
        
        {/* PROPS */}
        {buddy.currentActivity === ActivityState.READING && (
            <group position={[0, 0.1, 0.35]} rotation={[0.5, 0, 0]}>
                <mesh castShadow>
                    <boxGeometry args={[0.5, 0.05, 0.4]} />
                    <meshStandardMaterial color="#5D4037" />
                </mesh>
                <mesh position={[0, 0.03, 0]}>
                    <boxGeometry args={[0.45, 0.01, 0.35]} />
                    <meshStandardMaterial color="#FFF8E1" />
                </mesh>
            </group>
        )}
        
        {buddy.currentActivity === ActivityState.EATING && (
             <mesh position={[0, 0.2, 0.4]} castShadow>
                <sphereGeometry args={[0.15]} />
                <meshStandardMaterial color="#FF5252" /> 
             </mesh>
        )}
      </mesh>
      
      {/* Floating Emote */}
      {emote && (
        <Float speed={buddy.currentActivity === ActivityState.SLEEPING ? 1 : 2} rotationIntensity={0} floatIntensity={0.5}>
          <Text
            position={[0, 2.2, 0]}
            fontSize={buddy.currentActivity === ActivityState.SLEEPING ? 0.6 : 0.8}
            color="white"
            anchorX="center"
            anchorY="middle"
            outlineWidth={0.05}
            outlineColor="black"
          >
            {emote}
          </Text>
        </Float>
      )}
      
      {/* Name Tag */}
      {isSelected && (
        <Text
          position={[0, 1.8, 0]}
          fontSize={0.3}
          color="black"
          anchorX="center"
          anchorY="middle"
          outlineWidth={0.02}
          outlineColor="white"
        >
          {buddy.name}
        </Text>
      )}
    </group>
  );
};