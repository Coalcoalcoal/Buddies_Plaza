import React, { useMemo, useRef } from 'react';
import { Canvas, ThreeElements, useFrame } from '@react-three/fiber';
import { OrbitControls, SoftShadows, Stars } from '@react-three/drei';
import { BufferGeometry, BufferAttribute, Points, PointsMaterial } from 'three';
import { Buddy, WeatherCondition } from '../types';
import { BuddyMesh } from './BuddyMesh';
import { PLAZA_SIZE } from '../constants';

// Extend JSX.IntrinsicElements to include Three.js elements
declare global {
  namespace JSX {
    interface IntrinsicElements extends ThreeElements {}
  }
}

interface SceneProps {
  buddies: Buddy[];
  selectedBuddyId: string | null;
  onBuddyClick: (id: string) => void;
  onBackgroundClick: () => void;
  currentHour: number;
  weather: WeatherCondition;
}

const StreetLight: React.FC<{ position: [number, number, number], isOn: boolean }> = ({ position, isOn }) => {
  return (
    <group position={position}>
      {/* Pole */}
      <mesh position={[0, 2.5, 0]} castShadow>
        <cylinderGeometry args={[0.1, 0.15, 5]} />
        <meshStandardMaterial color="#2d3748" />
      </mesh>
      {/* Top Arm */}
      <mesh position={[0.4, 4.8, 0]} rotation={[0, 0, -0.2]}>
         <boxGeometry args={[1, 0.1, 0.2]} />
         <meshStandardMaterial color="#2d3748" />
      </mesh>
      {/* Light Bulb Housing */}
      <mesh position={[0.8, 4.6, 0]}>
         <coneGeometry args={[0.2, 0.4, 16]} />
         <meshStandardMaterial color="#2d3748" />
      </mesh>
      {/* The Light */}
      <mesh position={[0.8, 4.5, 0]}>
        <sphereGeometry args={[0.15]} />
        <meshBasicMaterial color={isOn ? "#fbbf24" : "#4b5563"} />
      </mesh>
      {isOn && (
        <pointLight 
            position={[0.8, 4.2, 0]} 
            intensity={2} 
            distance={15} 
            color="#fbbf24" 
            castShadow
            shadow-bias={-0.001}
        />
      )}
      {/* Glow effect */}
      {isOn && (
         <mesh position={[0.8, 4.2, 0]}>
             <sphereGeometry args={[0.4]} />
             <meshBasicMaterial color="#fbbf24" transparent opacity={0.3} />
         </mesh>
      )}
    </group>
  );
};

const Rain: React.FC = () => {
  const count = 2000;
  const positions = useMemo(() => {
    const pos = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      pos[i * 3] = (Math.random() - 0.5) * PLAZA_SIZE * 2.5; // x
      pos[i * 3 + 1] = Math.random() * 20; // y
      pos[i * 3 + 2] = (Math.random() - 0.5) * PLAZA_SIZE * 2.5; // z
    }
    return pos;
  }, []);

  const pointsRef = useRef<Points>(null);

  useFrame((state, delta) => {
    if (!pointsRef.current) return;
    const posAttribute = pointsRef.current.geometry.attributes.position;
    const array = posAttribute.array as Float32Array;

    for (let i = 0; i < count; i++) {
      let y = array[i * 3 + 1];
      y -= 15 * delta; // Fall speed
      if (y < 0) y = 20;
      array[i * 3 + 1] = y;
    }
    posAttribute.needsUpdate = true;
  });

  return (
    <points ref={pointsRef}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          count={positions.length / 3}
          array={positions}
          itemSize={3}
        />
      </bufferGeometry>
      <pointsMaterial color="#a3c1da" size={0.05} transparent opacity={0.6} sizeAttenuation />
    </points>
  );
};

export const Scene: React.FC<SceneProps> = ({ buddies, selectedBuddyId, onBuddyClick, onBackgroundClick, currentHour, weather }) => {
  // Day/Night Logic
  // Night is defined as 19:00 (7PM) to 05:00 (5AM)
  const isNight = currentHour >= 19 || currentHour < 5;
  // Streetlights on from 19:00 to 00:00 (Midnight)
  const areStreetLightsOn = currentHour >= 19 && currentHour < 24;

  const bgColors = useMemo(() => {
    if (isNight) {
        // Night Weather variants
        if (weather === WeatherCondition.RAINY) return { bg: '#0f0f1a', fog: '#0f0f1a', ambient: 0.1, sun: 0 };
        if (weather === WeatherCondition.CLOUDY) return { bg: '#151525', fog: '#151525', ambient: 0.15, sun: 0 };
        return { bg: '#1a1a2e', fog: '#1a1a2e', ambient: 0.2, sun: 0 };
    }
    
    // Day Weather variants
    if (weather === WeatherCondition.RAINY) return { bg: '#546e7a', fog: '#607d8b', ambient: 0.4, sun: 0.3 };
    if (weather === WeatherCondition.CLOUDY) return { bg: '#b0bec5', fog: '#cfd8dc', ambient: 0.5, sun: 0.6 };

    // Sunset transition (optional simple check)
    if (currentHour >= 17 && currentHour < 19) return { bg: '#fdba74', fog: '#fdba74', ambient: 0.5, sun: 0.8 };
    
    // Sunny Day
    return { bg: '#87CEEB', fog: '#87CEEB', ambient: 0.6, sun: 1.2 };
  }, [currentHour, isNight, weather]);

  // Generate Streetlamp positions around the plaza
  const streetLamps = useMemo(() => {
      const lamps = [];
      const count = 6;
      for(let i=0; i<count; i++) {
          const angle = (i / count) * Math.PI * 2;
          const r = PLAZA_SIZE - 2;
          lamps.push({
              key: i,
              pos: [Math.cos(angle) * r, 0, Math.sin(angle) * r] as [number, number, number],
              rot: -angle + Math.PI / 2 // Face inward
          });
      }
      return lamps;
  }, []);

  return (
    <Canvas 
      shadows 
      camera={{ position: [0, 15, 25], fov: 45 }} 
      onPointerMissed={(e) => {
        // Only trigger if the click wasn't on an object (type is actually MouseEvent | PointerEvent)
        if (e.type === 'click' || e.type === 'pointerup') {
            onBackgroundClick();
        }
      }}
    >
      <color attach="background" args={[bgColors.bg]} />
      <fog attach="fog" args={[bgColors.fog, 20, 60]} />
      
      {/* Sky/Stars */}
      {isNight && weather !== WeatherCondition.RAINY && weather !== WeatherCondition.CLOUDY && <Stars radius={100} depth={50} count={5000} factor={4} saturation={0} fade speed={1} />}

      {/* Rain Effect */}
      {weather === WeatherCondition.RAINY && <Rain />}

      {/* Lighting */}
      <ambientLight intensity={bgColors.ambient} />
      
      {/* Sun / Moon Light */}
      <directionalLight 
        position={[isNight ? -10 : 10, 20, isNight ? -10 : 10]} 
        intensity={isNight ? 0.2 : bgColors.sun} // Dim moonlight vs bright sun
        color={isNight ? "#b0c4de" : (weather === WeatherCondition.RAINY ? "#cfd8dc" : "#fff")}
        castShadow 
        shadow-mapSize={[1024, 1024]}
        shadow-camera-left={-25}
        shadow-camera-right={25}
        shadow-camera-top={25}
        shadow-camera-bottom={-25}
      />
      <SoftShadows size={10} samples={10} />

      <OrbitControls 
        maxPolarAngle={Math.PI / 2 - 0.1} 
        minDistance={5} 
        maxDistance={40} 
        enablePan={true}
      />

      {/* The Plaza Floor */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
        <circleGeometry args={[PLAZA_SIZE + 2, 64]} />
        <meshStandardMaterial color={weather === WeatherCondition.RAINY ? "#37474f" : (isNight ? "#2c3e50" : "#e8f5e9")} />
      </mesh>
      
      {/* Decorative center piece */}
      <mesh position={[0, 0.5, 0]} castShadow receiveShadow>
        <cylinderGeometry args={[2, 2.5, 1, 32]} />
        <meshStandardMaterial color="#dcdcdc" />
      </mesh>
       <mesh position={[0, 1, 0]} castShadow receiveShadow>
        <sphereGeometry args={[1.5, 32, 32]} />
        <meshStandardMaterial color="#556677" roughness={0.1} />
      </mesh>

      {/* Streetlights */}
      {streetLamps.map(lamp => (
          <group key={lamp.key} position={lamp.pos} rotation={[0, lamp.rot, 0]}>
             <StreetLight position={[0,0,0]} isOn={areStreetLightsOn} />
          </group>
      ))}

      {/* Buddies */}
      {buddies.map(buddy => (
        <BuddyMesh 
          key={buddy.id} 
          buddy={buddy} 
          onClick={onBuddyClick}
          isSelected={selectedBuddyId === buddy.id}
        />
      ))}
      
      {/* Simple Trees/Decor */}
      {[...Array(8)].map((_, i) => {
          const angle = (i / 8) * Math.PI * 2 + (Math.PI/8); // Offset from lamps
          const x = Math.cos(angle) * (PLAZA_SIZE - 4);
          const z = Math.sin(angle) * (PLAZA_SIZE - 4);
          return (
             <group key={i} position={[x, 0, z]}>
                <mesh position={[0, 1.5, 0]} castShadow>
                   <cylinderGeometry args={[0.3, 0.5, 3]} />
                   <meshStandardMaterial color="#5D4037" />
                </mesh>
                <mesh position={[0, 3.5, 0]} castShadow>
                   <dodecahedronGeometry args={[1.5]} />
                   <meshStandardMaterial color={isNight ? "#145A32" : (weather === WeatherCondition.RAINY ? "#2e7d32" : "#228B22")} />
                </mesh>
             </group>
          )
      })}

    </Canvas>
  );
};