
import React, { useEffect, useState } from 'react';
import { Users, Clock, Trash2, PlayCircle, PlusCircle } from 'lucide-react';
import { Buddy } from '../types';

export interface SaveData {
  timestamp: number;
  buddies: Buddy[];
}

interface MainMenuProps {
  onSelectSlot: (slotId: number, data: SaveData | null) => void;
}

export const MainMenu: React.FC<MainMenuProps> = ({ onSelectSlot }) => {
  const [slots, setSlots] = useState<(SaveData | null)[]>([null, null, null]);

  useEffect(() => {
    // Load slots metadata
    const loadedSlots = [1, 2, 3].map(i => {
      const saved = localStorage.getItem(`plaza_save_${i}`);
      return saved ? JSON.parse(saved) : null;
    });
    setSlots(loadedSlots);
  }, []);

  const handleDelete = (e: React.MouseEvent, index: number) => {
    e.stopPropagation();
    if (confirm("Are you sure you want to delete this save? This cannot be undone.")) {
        localStorage.removeItem(`plaza_save_${index + 1}`);
        const newSlots = [...slots];
        newSlots[index] = null;
        setSlots(newSlots);
    }
  };

  return (
    <div className="absolute inset-0 z-50 flex flex-col items-center justify-center p-8 backdrop-blur-sm bg-sky-900/30">
      
      <div className="text-center mb-12">
        <h1 className="text-7xl font-black text-white drop-shadow-[0_5px_5px_rgba(0,0,0,0.3)] tracking-wider transform -rotate-2 stroke-black">
          PLAZA POPULO
        </h1>
        <p className="text-white font-bold text-xl mt-4 drop-shadow-md bg-black/20 inline-block px-4 py-1 rounded-full">
            Select a world to enter
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 w-full max-w-6xl px-4">
        {slots.map((slot, index) => (
          <div 
            key={index}
            onClick={() => onSelectSlot(index + 1, slot)}
            className={`
              relative group cursor-pointer transition-all duration-300 transform
              ${slot ? 'bg-white hover:bg-sky-50' : 'bg-white/60 hover:bg-white/90'}
              rounded-[2rem] p-6 h-80 border-b-8 border-r-8 hover:-translate-y-2 hover:border-b-[12px]
              ${slot ? 'border-gray-200' : 'border-gray-300'}
              shadow-2xl flex flex-col items-center justify-center text-center
            `}
          >
            <div className="absolute top-4 left-4 bg-gray-200 text-gray-600 font-bold px-3 py-1 rounded-full text-sm">
                Slot {index + 1}
            </div>

            {slot ? (
              <>
                <div className="bg-toon-green/10 p-5 rounded-full mb-6 group-hover:scale-110 group-hover:bg-toon-green/20 transition-all duration-300">
                    <PlayCircle className="w-16 h-16 text-toon-green" />
                </div>
                
                <div className="text-gray-600 font-medium space-y-3 w-full">
                    <div className="bg-gray-100 rounded-xl p-2 flex items-center justify-center gap-2 mx-4">
                        <Users className="w-5 h-5 text-toon-blue" /> 
                        <span className="font-bold text-lg">{slot.buddies.length}</span> <span className="text-sm">Buddies</span>
                    </div>
                    <div className="flex items-center justify-center gap-2 text-sm text-gray-400">
                         <Clock className="w-4 h-4" /> 
                         {new Date(slot.timestamp).toLocaleDateString()} {new Date(slot.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                    </div>
                </div>
                
                <button 
                    onClick={(e) => handleDelete(e, index)}
                    className="absolute top-4 right-4 p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-full transition-colors z-10"
                    title="Delete Save"
                >
                    <Trash2 className="w-5 h-5" />
                </button>
              </>
            ) : (
               <>
                <div className="bg-gray-100 p-5 rounded-full mb-6 group-hover:scale-110 transition-transform border-4 border-dashed border-gray-300">
                    <PlusCircle className="w-16 h-16 text-gray-400" />
                </div>
                <h3 className="text-2xl font-bold text-gray-500 mb-2 group-hover:text-toon-blue transition-colors">New World</h3>
                <p className="text-gray-400 text-sm px-8">Start a fresh simulation with 10 random buddies.</p>
               </>
            )}
          </div>
        ))}
      </div>
      
      <div className="mt-12 text-white/70 font-medium text-sm">
        Simulated in real-time • Local Storage Enabled
      </div>
    </div>
  );
}
