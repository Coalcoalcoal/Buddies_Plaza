import { Buddy, Gender, Personality, ActivityState, Vector3, Relationship } from '../types';
import { NAMES_MALE, NAMES_FEMALE, COLORS, PLAZA_SIZE } from '../constants';

const randomRange = (min: number, max: number) => Math.random() * (max - min) + min;
const randomInt = (min: number, max: number) => Math.floor(randomRange(min, max));

export const generateRandomPosition = (): Vector3 => {
  const angle = Math.random() * Math.PI * 2;
  const radius = Math.sqrt(Math.random()) * (PLAZA_SIZE - 2); // Keep them slightly inside
  return {
    x: Math.cos(angle) * radius,
    y: 0,
    z: Math.sin(angle) * radius
  };
};

const generatePersonality = (): Personality => ({
  energy: randomInt(10, 100),
  mood: randomInt(20, 100),
  overall: randomInt(30, 90),
  speech: randomInt(10, 100)
});

export const generateBuddies = (count: number): Buddy[] => {
  const buddies: Buddy[] = [];
  for (let i = 0; i < count; i++) {
    const gender = Math.random() > 0.5 ? Gender.Male : Gender.Female;
    const nameList = gender === Gender.Male ? NAMES_MALE : NAMES_FEMALE;
    const name = nameList[randomInt(0, nameList.length)];
    const uniqueName = `${name} ${String.fromCharCode(65 + i)}`; // Ensure unique names simply

    buddies.push({
      id: crypto.randomUUID(),
      name: uniqueName,
      gender,
      color: COLORS[i % COLORS.length],
      personality: generatePersonality(),
      position: generateRandomPosition(),
      targetPosition: null,
      rotation: Math.random() * Math.PI * 2,
      currentActivity: ActivityState.IDLE,
      activityDuration: 0,
      relationships: {},
      interactingWith: []
    });
  }
  return buddies;
};

// Calculate distance between two vectors
export const dist = (v1: Vector3, v2: Vector3): number => {
  const dx = v1.x - v2.x;
  const dz = v1.z - v2.z;
  return Math.sqrt(dx * dx + dz * dz);
};
