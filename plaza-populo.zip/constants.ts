export const PLAZA_SIZE = 18; // Radius of the area
export const POPULATION_COUNT = 10;
export const TICK_RATE = 100; // Simulation logic update in ms (10 times a second)
export const MOVE_SPEED = 0.08;

export const NAMES_MALE = ["Alex", "Ben", "Charlie", "David", "Ethan", "Frank", "George", "Henry", "Ian", "Jack"];
export const NAMES_FEMALE = ["Alice", "Bella", "Chloe", "Diana", "Emma", "Fiona", "Grace", "Hannah", "Ivy", "Jane"];
export const COLORS = [
  "#FF6B6B", "#4ECDC4", "#45B7D1", "#FFA07A", "#98D8C8",
  "#F7DC6F", "#BB8FCE", "#F1948A", "#82E0AA", "#85C1E9"
];

export const RELATIONSHIP_THRESHOLDS = {
  FOE: -50,
  FRIENEMY: -10,
  NEUTRAL: 10,
  FRIEND: 50,
  // Above 50 is Best Friend
};

// Helper to get tier
import { RelationshipTier } from './types';

export const getRelationshipTier = (score: number): RelationshipTier => {
  if (score <= RELATIONSHIP_THRESHOLDS.FOE) return RelationshipTier.FOE;
  if (score <= RELATIONSHIP_THRESHOLDS.FRIENEMY) return RelationshipTier.FRIENEMY;
  if (score <= RELATIONSHIP_THRESHOLDS.NEUTRAL) return RelationshipTier.NEUTRAL;
  if (score <= RELATIONSHIP_THRESHOLDS.FRIEND) return RelationshipTier.FRIEND;
  return RelationshipTier.BEST_FRIEND;
};

export const getRelationshipColor = (score: number): string => {
  if (score <= RELATIONSHIP_THRESHOLDS.FOE) return "text-red-600";
  if (score <= RELATIONSHIP_THRESHOLDS.FRIENEMY) return "text-orange-500";
  if (score <= RELATIONSHIP_THRESHOLDS.NEUTRAL) return "text-gray-400";
  if (score <= RELATIONSHIP_THRESHOLDS.FRIEND) return "text-green-500";
  return "text-green-700 font-bold";
};
