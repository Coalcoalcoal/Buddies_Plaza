export enum Gender {
  Male = 'Male',
  Female = 'Female',
  NonBinary = 'Non-Binary'
}

export enum ActivityState {
  IDLE = 'IDLE',
  WALKING = 'WALKING',
  TALKING = 'TALKING',
  DANCING = 'DANCING',
  EXERCISING = 'EXERCISING',
  SITTING = 'SITTING',
  READING = 'READING',
  PLAYING = 'PLAYING',
  EATING = 'EATING',
  SLEEPING = 'SLEEPING'
}

export enum RelationshipTier {
  FOE = 'Foe',
  FRIENEMY = 'Frienemy',
  NEUTRAL = 'Neutral',
  FRIEND = 'Friend',
  BEST_FRIEND = 'Best Friend'
}

export enum WeatherCondition {
  SUNNY = 'Sunny',
  CLOUDY = 'Cloudy',
  RAINY = 'Rainy'
}

export interface Vector3 {
  x: number;
  y: number;
  z: number;
}

export interface Personality {
  energy: number; // 0-100: Determines speed and exercise frequency
  mood: number;   // 0-100: Determines relationship gain/loss chance
  overall: number; // 0-100: General charisma
  speech: number; // 0-100: How talkative they are
}

export interface Relationship {
  targetId: string;
  score: number; // -100 to 100
}

export interface Buddy {
  id: string;
  name: string;
  gender: Gender;
  color: string;
  personality: Personality;
  
  // Dynamic State
  position: Vector3;
  targetPosition: Vector3 | null;
  rotation: number;
  currentActivity: ActivityState;
  activityDuration: number; // How many ticks left in current activity
  
  // Social
  relationships: Record<string, Relationship>; // Map of other buddy ID to relationship
  interactingWith: string[]; // IDs of buddies currently interacting with
}