
import React, { useState, useEffect, useCallback } from 'react';
import { Scene } from './components/Scene';
import { UI } from './components/UI';
import { MainMenu, SaveData } from './components/MainMenu';
import { Buddy, ActivityState, WeatherCondition } from './types';
import { generateBuddies, dist, generateRandomPosition } from './utils/simulationUtils';
import { TICK_RATE, MOVE_SPEED, POPULATION_COUNT } from './constants';

export default function App() {
  const [buddies, setBuddies] = useState<Buddy[]>([]);
  const [activeSlot, setActiveSlot] = useState<number | null>(null);
  const [selectedBuddyId, setSelectedBuddyId] = useState<string | null>(null);
  const [lastSaved, setLastSaved] = useState<Date | null>(null);
  const [currentHour, setCurrentHour] = useState(new Date().getHours());
  const [weather, setWeather] = useState<WeatherCondition>(WeatherCondition.SUNNY);
  const [isLoadingWeather, setIsLoadingWeather] = useState(true);

  // --- Weather & Time Synchronization ---
  useEffect(() => {
    // 1. Time Sync
    const hourTimer = setInterval(() => {
        setCurrentHour(new Date().getHours());
    }, 10000); // Check every 10s

    // 2. Weather Sync Logic
    const fetchWeatherFromAPI = async (lat: number, lon: number) => {
        try {
            const response = await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current_weather=true`);
            const data = await response.json();
            const code = data.current_weather.weathercode;

            // Map WMO codes to our types
            let condition = WeatherCondition.SUNNY;
            if (code <= 1) condition = WeatherCondition.SUNNY;
            else if (code <= 48) condition = WeatherCondition.CLOUDY;
            else condition = WeatherCondition.RAINY;

            console.log(`Weather updated: Code ${code} -> ${condition}`);
            setWeather(condition);
        } catch (error) {
            console.error("Failed to fetch weather:", error);
            setWeather(WeatherCondition.SUNNY);
        } finally {
            setIsLoadingWeather(false);
        }
    };

    const initWeather = () => {
        setIsLoadingWeather(true);
        if ("geolocation" in navigator) {
            navigator.geolocation.getCurrentPosition(
                (position) => {
                    fetchWeatherFromAPI(position.coords.latitude, position.coords.longitude);
                },
                async (error) => {
                    console.warn("Geolocation denied or failed, falling back to IP:", error);
                    try {
                        const ipRes = await fetch('https://get.geojs.io/v1/ip/geo.json');
                        const ipData = await ipRes.json();
                        fetchWeatherFromAPI(parseFloat(ipData.latitude), parseFloat(ipData.longitude));
                    } catch (ipError) {
                        console.error("IP Geolocation failed:", ipError);
                        setIsLoadingWeather(false);
                    }
                }
            );
        } else {
             setIsLoadingWeather(false);
        }
    };

    initWeather();
    const weatherInterval = setInterval(initWeather, 15 * 60 * 1000);

    return () => {
        clearInterval(hourTimer);
        clearInterval(weatherInterval);
    };
  }, []);

  // --- Initialization ---
  // On mount, we don't load specific slot, but we generate background buddies for the menu
  useEffect(() => {
    setBuddies(generateBuddies(POPULATION_COUNT));
  }, []);

  // --- Menu Handlers ---
  const handleSelectSlot = (slotId: number, data: SaveData | null) => {
      setActiveSlot(slotId);
      if (data) {
          setBuddies(data.buddies);
      } else {
          setBuddies(generateBuddies(POPULATION_COUNT));
      }
  };

  const handleExit = () => {
      setActiveSlot(null);
      setSelectedBuddyId(null);
      // Regenerate background buddies for variety
      setBuddies(generateBuddies(POPULATION_COUNT));
  };

  const handleReset = () => {
    if (confirm("Reset current world?")) {
        const newBuddies = generateBuddies(POPULATION_COUNT);
        setBuddies(newBuddies);
        setSelectedBuddyId(null);
        // We don't clear storage immediately unless they save, or we can clear it now:
        // localStorage.removeItem(`plaza_save_${activeSlot}`);
    }
  };

  const handleSave = () => {
    if (activeSlot === null) return;
    
    const data: SaveData = {
        timestamp: Date.now(),
        buddies: buddies
    };
    
    localStorage.setItem(`plaza_save_${activeSlot}`, JSON.stringify(data));
    setLastSaved(new Date());
    setTimeout(() => setLastSaved(null), 2000);
  };

  // --- Core Simulation Loop ---
  const updateSimulation = useCallback(() => {
    const now = new Date();
    const hour = now.getHours();
    const isNight = hour >= 19 || hour < 5;

    setBuddies(prevBuddies => {
      const buddyMap = new Map(prevBuddies.map(b => [b.id, b]));

      return prevBuddies.map(buddy => {
        const newBuddy = { ...buddy };

        if (newBuddy.activityDuration > 0) {
          newBuddy.activityDuration -= 1;
        }

        // --- STATE LOGIC START ---
        
        // SLEEPING
        if (isNight) {
            if (newBuddy.currentActivity !== ActivityState.SLEEPING) {
                 newBuddy.currentActivity = ActivityState.SLEEPING;
                 newBuddy.activityDuration = 100;
                 newBuddy.targetPosition = null;
                 newBuddy.interactingWith = [];
            } else {
                newBuddy.activityDuration = 100;
            }
        } else {
            if (newBuddy.currentActivity === ActivityState.SLEEPING) {
                newBuddy.currentActivity = ActivityState.IDLE;
                newBuddy.activityDuration = 0;
            }
        }

        // WEATHER MOOD
        if (!isNight && weather === WeatherCondition.RAINY) {
            if (Math.random() > 0.995 && newBuddy.personality.mood > 0) {
                newBuddy.personality.mood = Math.max(0, newBuddy.personality.mood - 1);
            }
        }

        // ACTIVITIES
        if (newBuddy.currentActivity !== ActivityState.SLEEPING && newBuddy.activityDuration <= 0) {
          const rand = Math.random();
          
          if (newBuddy.currentActivity === ActivityState.WALKING) {
            newBuddy.currentActivity = ActivityState.IDLE;
            newBuddy.activityDuration = Math.floor(20 + Math.random() * 40);
            newBuddy.targetPosition = null;
          } else if (newBuddy.currentActivity === ActivityState.IDLE) {
             let energyFactor = newBuddy.personality.energy / 100;
             if (weather === WeatherCondition.RAINY) energyFactor *= 0.5;

             if (rand < 0.4 * energyFactor) {
                 newBuddy.currentActivity = ActivityState.WALKING;
                 newBuddy.targetPosition = generateRandomPosition();
                 newBuddy.activityDuration = 1000;
                 newBuddy.interactingWith = [];
             } else if (rand < 0.8) {
                 let closest: Buddy | null = null;
                 let minDist = 5;
                 
                 for (const other of prevBuddies) {
                     if (other.id === newBuddy.id) continue;
                     if (other.currentActivity === ActivityState.SLEEPING) continue;
                     
                     const d = dist(newBuddy.position, other.position);
                     if (d < minDist) {
                         minDist = d;
                         closest = other;
                     }
                 }

                 if (closest && minDist < 3) {
                     const other = closest;
                     const combinedEnergy = (newBuddy.personality.energy + other.personality.energy) / 2;
                     
                     let activity = ActivityState.TALKING;
                     const randAct = Math.random();

                     if (combinedEnergy > 75 && weather !== WeatherCondition.RAINY) {
                        if (randAct < 0.35) activity = ActivityState.DANCING;
                        else if (randAct < 0.65) activity = ActivityState.EXERCISING;
                        else activity = ActivityState.PLAYING;
                     } else if (combinedEnergy > 45) {
                        if (randAct < 0.4) activity = ActivityState.TALKING;
                        else if (randAct < 0.7) activity = ActivityState.EATING;
                        else activity = ActivityState.PLAYING;
                     } else {
                        if (randAct < 0.4) activity = ActivityState.SITTING;
                        else if (randAct < 0.7) activity = ActivityState.READING;
                        else activity = ActivityState.TALKING;
                     }

                     newBuddy.currentActivity = activity;
                     newBuddy.activityDuration = Math.floor(50 + Math.random() * 100);
                     newBuddy.rotation = Math.atan2(other.position.x - newBuddy.position.x, other.position.z - newBuddy.position.z);
                     if (!newBuddy.interactingWith.includes(other.id)) newBuddy.interactingWith.push(other.id);
                 } else {
                     const soloRand = Math.random();
                     if (soloRand > 0.7) {
                         newBuddy.currentActivity = ActivityState.SITTING;
                         newBuddy.activityDuration = 60;
                     } else if (soloRand > 0.9 && newBuddy.personality.overall > 60) {
                         newBuddy.currentActivity = ActivityState.READING;
                         newBuddy.activityDuration = 80;
                     }
                 }
             }
          }
        }

        // MOVEMENT
        if (newBuddy.currentActivity === ActivityState.WALKING && newBuddy.targetPosition) {
          const dx = newBuddy.targetPosition.x - newBuddy.position.x;
          const dz = newBuddy.targetPosition.z - newBuddy.position.z;
          const distance = Math.sqrt(dx * dx + dz * dz);

          if (distance < 0.5) {
            newBuddy.currentActivity = ActivityState.IDLE;
            newBuddy.activityDuration = 20;
            newBuddy.targetPosition = null;
          } else {
            let speedMod = newBuddy.personality.energy / 50;
            if (weather === WeatherCondition.RAINY) speedMod *= 1.2;

            const moveX = (dx / distance) * MOVE_SPEED * speedMod;
            const moveZ = (dz / distance) * MOVE_SPEED * speedMod;
            
            newBuddy.position = {
                x: newBuddy.position.x + moveX,
                y: 0,
                z: newBuddy.position.z + moveZ
            };
            newBuddy.rotation = Math.atan2(dx, dz);
          }
        }

        // RELATIONSHIPS
        if ([ActivityState.TALKING, ActivityState.DANCING, ActivityState.EXERCISING, ActivityState.SITTING, ActivityState.PLAYING, ActivityState.READING, ActivityState.EATING].includes(newBuddy.currentActivity)) {
             newBuddy.interactingWith.forEach(otherId => {
                 const other = buddyMap.get(otherId);
                 if (!other) return;

                 if (Math.random() > 0.05) return;

                 const currentRel = newBuddy.relationships[otherId] || { targetId: otherId, score: 0 };
                 const moodDiff = Math.abs(newBuddy.personality.mood - other.personality.mood);
                 
                 let change = 0;
                 if (moodDiff < 20) change += 0.5;
                 else if (moodDiff > 60) change -= 0.5;

                 if (newBuddy.currentActivity === ActivityState.PLAYING) change += 0.8;
                 if (newBuddy.currentActivity === ActivityState.EATING) change += 0.6;
                 if (newBuddy.currentActivity === ActivityState.READING) change += 0.3;
                 if (newBuddy.currentActivity === ActivityState.DANCING) change += 0.7;

                 const charismaRoll = Math.random() * 100;
                 if (charismaRoll < newBuddy.personality.overall) change += 0.2;

                 let newScore = currentRel.score + change;
                 if (newScore > 100) newScore = 100;
                 if (newScore < -100) newScore = -100;

                 newBuddy.relationships[otherId] = { ...currentRel, score: newScore };
             });
        }
        
        newBuddy.interactingWith = newBuddy.interactingWith.filter(id => {
            const other = buddyMap.get(id);
            if (!other) return false;
            return dist(newBuddy.position, other.position) < 5;
        });

        return newBuddy;
      });
    });
  }, [weather]);

  useEffect(() => {
    const interval = setInterval(updateSimulation, TICK_RATE);
    return () => clearInterval(interval);
  }, [updateSimulation]);

  const selectedBuddy = buddies.find(b => b.id === selectedBuddyId) || null;

  return (
    <div className="w-full h-screen relative bg-blue-200 overflow-hidden">
      {/* Scene is always rendered for background visuals */}
      <Scene 
        buddies={buddies} 
        selectedBuddyId={activeSlot ? selectedBuddyId : null} 
        onBuddyClick={(id) => activeSlot && setSelectedBuddyId(id)} 
        onBackgroundClick={() => setSelectedBuddyId(null)}
        currentHour={currentHour}
        weather={weather}
      />
      
      {activeSlot ? (
          <UI 
            selectedBuddy={selectedBuddy} 
            allBuddies={buddies}
            onReset={handleReset}
            onSave={handleSave}
            onExit={handleExit}
            lastSaved={lastSaved}
            weather={weather}
          />
      ) : (
          <MainMenu onSelectSlot={handleSelectSlot} />
      )}
    </div>
  );
}
